var express = require('express'); // Importa o express;

var app = express();

module.exports = app; // Módulo retorna a variável app;