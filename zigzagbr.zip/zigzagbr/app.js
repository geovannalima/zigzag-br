var app = require('./config/server');

app.listen(5000, function(){
	console.log("Servidor on");
});